public class StudentManagement {
    private Student[] students = new Student[100];
    private int stuSize = 0;

    public static boolean sameGroup(Student s1, Student s2) {
        return s1.getGroup().equals(s2.getGroup());
    }

    public void addStudent(Student newStudent) {
        students[stuSize] = newStudent;
        stuSize++;
    }

    public void removeStudent(String id) {
        for (int i = 0; i < stuSize; i++) {
            if (students[i].getId().equals(id)) {
                for (int j = i; j < stuSize - 1; j++) {
                    students[j] = students[j + 1];
                }
            }
            students[stuSize - 1] = null;
            stuSize--;
        }
    }

    /**
     * Returns a string containing students grouped by their group.
     * <p>
     * Output format:
     * <p>
     * GroupName1
     * Name1 - ID1 - Group1 - Email1
     * Name2 - ID2 - Group1 - Email2
     * <p>
     * GroupName2
     * Name3 - ID3 - Group2 - Email3
     * ...
     * <p>
     * If there are no students, an empty string ("") is returned.
     *
     * @return a string of students grouped by their group
     */


    public String studentsByGroup() {
        String s = "";
        boolean[] visited = new boolean[stuSize]; //tham khảo chatgpt

        for (int i = 0; i < stuSize; i++) {
            if (!visited[i]) {
                String group = students[i].getGroup();
                s += group + "\n";
                for (int j = 0; j < stuSize; j++) {
                    if (!visited[j] && students[j].getGroup().equals(group)) {
                        s += students[j].getName() + " - "
                                + students[j].getId() + " - "
                                + students[j].getGroup() + " - "
                                + students[j].getEmail() + "\n";
                        visited[j] = true;
                    }
                }
            }
        }
        return s.toString();
    }
}