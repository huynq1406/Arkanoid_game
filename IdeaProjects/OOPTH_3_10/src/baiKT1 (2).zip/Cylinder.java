public class Cylinder extends Circle {
    private double height;

    /**
     *
     * @param radius
     * @param color
     * @param height
     */
    public Cylinder(double radius, String color, double height) {
        super(radius, color);
        this.height = height;
    }

    /**
     * Description.
     */

    Cylinder(double radius, double height) {
        super(radius);
        this.height = height;
    }

    /**
     * Description.
     */

    Cylinder(double radius) {
        super(radius);
        height = 1.0;
    }
    /**
     * Description.
     */

    Cylinder() {
        super();
        height = 1.0;
    }


    /**
     * Description.
     */

    public double getHeight() {
        return height;
    }


    /**
     * Description.
     */

    public void setHeight(double height) {
        this.height = height;
    }


    /**
     * Description.
     */

    public double getVolume() {
        return height * getArea();
    }

    /**
     * Description.
     */

    public String toString() {
        return "Cylinder[" + super.toString() + "height=" + height + "]";
    }

    /**
     * Description.
     */

    public double getArea() {
        return super.getArea() * 2 + 2 * super.getArea() / getRadius() * height;
    }
}
