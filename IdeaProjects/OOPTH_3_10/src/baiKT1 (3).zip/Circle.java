public class Circle {
    private double radius;
    private String color;
    protected static final double PI = 3.141592653589793;

    /**
     * Description.
     */
    public Circle() {
        this.radius = 1.0;
        this.color = "Blue";
    }

    /**
     * Description.
     */
    public Circle(double radius) {
        this.radius = radius;
        this.color = "Blue";
    }

    /**
     * Description.
     */
    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    /**
     * Description.
     */
    public String getColor() {
        return color;
    }

    /**
     * Description.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Description.
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Description.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Description.
     */
    public double getArea() {
        return PI * radius * radius;
    }

    /**
     * Description.
     */
    public String toString() {
        return "Circle[" + "radius=" + radius + ", color=" + color + ']';
    }
}
